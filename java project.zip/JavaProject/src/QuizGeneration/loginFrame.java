package QuizGeneration;

import javax.swing.*;



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
public class loginFrame extends JFrame implements ActionListener {
 
    Container container = getContentPane();
    JLabel userLabel = new JLabel("USERNAME");
    JLabel passwordLabel = new JLabel("PASSWORD");
    JTextField userTextField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JButton loginButton = new JButton("LOGIN");
    JButton resetButton = new JButton("RESET");
    JCheckBox showPassword = new JCheckBox("Show Password");
   
    String username;
    loginFrame(String username) {
    	setTitle("Login Form");
       setVisible(true);
        setBounds(100, 30, 1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
  
    
    	 JLabel l2 = new JLabel("Let's Start");
         l2.setFont(new Font("Viner Hand ITC", Font.BOLD, 40));
         l2.setForeground(new Color(30, 144, 254));
         l2.setBounds(80, 180, 300, 45);
         add(l2);
//        
    	setLayout(null);
    	ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/login.jpg"));
    	 JLabel l1 = new JLabel(i1);
    	 l1.setBounds(300, 0, 700, 700);
       
    	 ImageIcon i2 = new ImageIcon(ClassLoader.getSystemResource("icon/AP shah.jpg"));
    	 JLabel l3 = new JLabel(i2);
    	 l3.setBounds(80, 0, 200, 200);
    	 add(l3);
        add(l1);
    	getContentPane().setBackground(Color.WHITE);
    	
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();
        addActionEvent();
        setFontcolor();
       
 
    }
  public void setFontcolor() {
	  userLabel .setForeground(new Color(30, 144, 254));
	  passwordLabel .setForeground(new Color(30, 144, 254));
	  loginButton .setBackground(new Color(30, 144, 254));
	  loginButton .setForeground(Color.WHITE);
	  resetButton .setBackground(new Color(30, 144, 254));
	  resetButton .setForeground(Color.WHITE);
	  showPassword .setBackground(Color.WHITE);
	  userTextField.setFont(new Font("Times New Roman", Font.BOLD, 20));
	 
  }
 
    public void setLayoutManager() {
        container.setLayout(null);
    }
 
    public void setLocationAndSize() {
        userLabel.setBounds(50, 250, 100, 30);
        passwordLabel.setBounds(50, 300, 100, 30);
        userTextField.setBounds(150, 250, 150, 30);
        passwordField.setBounds(150, 300, 150, 30);
        showPassword.setBounds(150, 330, 150, 30);
        loginButton.setBounds(50, 380, 100, 30);
        resetButton.setBounds(200, 380, 100, 30);
       
        
        
 
    }
 
    public void addComponentsToContainer() {
        container.add(userLabel);
        container.add(passwordLabel);
        container.add(userTextField);
        container.add(passwordField);
        container.add(showPassword);
        container.add(loginButton);
        container.add(resetButton);
       
    }
 
    public void addActionEvent() {
        loginButton.addActionListener(this);
        resetButton.addActionListener(this);
        showPassword.addActionListener(this);
       
    }
 
 
    @Override
    public void actionPerformed(ActionEvent e) {
        //Coding Part of LOGIN button
        if (e.getSource() == loginButton) {
            String userText;
            String pwdText;
            userText = userTextField.getText();
            pwdText = passwordField.getText();
           
//            userText.equalsIgnoreCase(username) && pwdText.equalsIgnoreCase("12345")
            if (userText.equalsIgnoreCase("yogesh") && pwdText.equalsIgnoreCase("12345")) {
                JOptionPane.showMessageDialog(this, "Login Successful");
                new Subject(userText); 
                 this.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Username or Password");
                
          
            }
 
        }
        //Coding Part of RESET button
        if (e.getSource() == resetButton) {
            userTextField.setText("");
            passwordField.setText("");
        }
       //Coding Part of showPassword JCheckBox
        if (e.getSource() == showPassword) {
            if (showPassword.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            }
 
        }
//      if(e.getSource() == next){
           
       //    this.setVisible(false);
//           new OnlineTest1("Online Test App"); 
        }
    
 

 

    public static void main(String[] a) {
         new loginFrame("");
        }
 
    }
 