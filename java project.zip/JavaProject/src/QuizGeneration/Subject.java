package QuizGeneration;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Subject extends JFrame implements ActionListener{
    JButton b1, b2,b3,b4,b5;
    String username;
    Subject(String username){
    	 this.username = username;
        setBounds(100, 30, 1200, 650);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel l1 = new JLabel("Welcome " + username +" .");
        l1.setForeground(new Color(30, 144, 255));
        l1.setFont(new Font("Viner Hand ITC", Font.BOLD, 28));
        l1.setBounds(50, 20, 700, 30);
        add(l1);
        
        ImageIcon i2 = new ImageIcon(ClassLoader.getSystemResource("icon/AP shah.jpg"));
   	 JLabel l3 = new JLabel(i2);
   	 l3.setBounds(250, 350, 200, 200);
   	 add(l3);
   	ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/y1.jpg"));
	 JLabel l2 = new JLabel(i1);
	 l2.setBounds(600, 50, 512, 512);
	 add(l2);
       
        b1 = new JButton("Engineering Mathematics-III");
        b1.setBounds(200, 100, 300, 30);
        b1.setBackground(new Color(30, 144, 255));
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        add(b1);
        
        b2 = new JButton("Data Structures and Analysis");
        b2.setBounds(200, 150, 300, 30);
        b2.setBackground(new Color(30, 144, 255));
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);
        add(b2);
        
        b3 = new JButton("principal of communiction");
        b3.setBounds(200, 200, 300, 30);
        b3.setBackground(new Color(30, 144, 255));
        b3.setForeground(Color.WHITE);
        b3.addActionListener(this);
        add(b3);
        
        b4 = new JButton("Database Management System");
        b4.setBounds(200, 250, 300, 30);
        b4.setBackground(new Color(30, 144, 255));
        b4.setForeground(Color.WHITE);
        b4.addActionListener(this);
        add(b4);
        
        b5 = new JButton("Paradigms and Computer Programming Fundamentals");
        b5.setBounds(200, 300, 350, 30);
        b5.setBackground(new Color(30, 144, 255));
        b5.setForeground(Color.WHITE);
        b5.addActionListener(this);
        add(b5);
        
       
        
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == b1){
            this.setVisible(false);
            new OnlineTest1("Engineering Mathematics-III"); 
           
        }else if(ae.getSource() == b2){
            this.setVisible(false);
           
        }
    
    if(ae.getSource() == b2){
        this.setVisible(false);
        new OnlineTest2("Data Structure and Analysis"); 
       
    }
    if(ae.getSource() == b3){
        this.setVisible(false);
        new OnlineTest3("principal of communiction"); 
       
    }
    if(ae.getSource() == b4){
        this.setVisible(false);
        new OnlineTest4("Database Management System"); 
       
    }
    if(ae.getSource() == b5){
        this.setVisible(false);
        new OnlineTest5("Paradigms and Computer Programming Fundamentals");
       
    }
}
    public static void main(String[] args){
        new Subject("");
    }
}
